from robot_arm import RobotArm3DoF


arm = RobotArm3DoF()
arm.move(0.1, 0.1, 0)
